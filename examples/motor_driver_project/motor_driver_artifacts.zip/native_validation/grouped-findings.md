# Native Validation Findings by Class

## Severity Distribution

| Source | error | warning | Total |
|---|---:|---:|---:|
| drc | 25 | 40 | 65 |
| parity | 0 | 18 | 18 |
| **Total** | **25** | **58** | **83** |

## Top Categories

| Rank | Source | Severity | Type | Count | Message | Example |
|---:|---|---|---|---:|---|---|
| 1 | drc | warning | lib_footprint_issues | 29 | 在库 'TestPoint' 中找不到封装 'TestPoint_Pad_D1.2mm' |  |
| 2 | drc | error | solder_mask_bridge | 12 | 顶层阻焊开窗区域与不同网络的项目相连 |  |
| 3 | drc | error | clearance | 4 | 间距违规 ( 间距 0.2000 mm; 实际 0.0400 mm) |  |
| 4 | drc | warning | lib_footprint_issues | 3 | 在库 'Fiducial' 中找不到封装 'Fiducial_1.0mm_Mask2.0mm' |  |
| 5 | drc | warning | lib_footprint_issues | 3 | 在库 'Resistor_SMD' 中找不到封装 'R_0402_1005x0500Metric' |  |
| 6 | drc | warning | lib_footprint_issues | 2 | 在库 'MountingHole' 中找不到封装 'MountingHole_3.2mm' |  |
| 7 | drc | warning | lib_footprint_issues | 2 | 在库 'Resistor_SMD' 中找不到封装 'R_0603_1608x0800Metric' |  |
| 8 | drc | error | shorting_items | 2 | 短路了两个不同网络的项目 (网络 和 3V3) |  |
| 9 | drc | error | clearance | 1 | 间距违规 ( 间距 0.2000 mm; 实际 0.1553 mm) |  |
| 10 | drc | warning | lib_footprint_issues | 1 | 当前配置中不包含封装库 'motor_driver_footprints' |  |
| 11 | drc | error | shorting_items | 1 | 短路了两个不同网络的项目 (网络 ENC_B 和 ) |  |
| 12 | drc | error | shorting_items | 1 | 短路了两个不同网络的项目 (网络 NRST 和 ) |  |
| 13 | drc | error | shorting_items | 1 | 短路了两个不同网络的项目 (网络 PWM_AH 和 ) |  |
| 14 | drc | error | shorting_items | 1 | 短路了两个不同网络的项目 (网络 PWM_CH 和 ) |  |
| 15 | drc | error | shorting_items | 1 | 短路了两个不同网络的项目 (网络 和 ENC_A) |  |
| 16 | drc | error | shorting_items | 1 | 短路了两个不同网络的项目 (网络 和 nFAULT) |  |
| 17 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (3V3) 指定的网络 |  |
| 18 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (CAN_RX) 指定的网络 |  |
| 19 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (CAN_TX) 指定的网络 |  |
| 20 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (DC_BUS) 指定的网络 |  |
| 21 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (ENABLE) 指定的网络 |  |
| 22 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (GND) 指定的网络 |  |
| 23 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (I_SENSE_A) 指定的网络 |  |
| 24 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (I_SENSE_B) 指定的网络 |  |
| 25 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (PWM_AH) 指定的网络 |  |
| 26 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (PWM_AL) 指定的网络 |  |
| 27 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (PWM_BH) 指定的网络 |  |
| 28 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (SWCLK) 指定的网络 |  |
| 29 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (SWDIO) 指定的网络 |  |
| 30 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (TEMP_MOTOR) 指定的网络 |  |
| 31 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (UART_RX) 指定的网络 |  |
| 32 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (UART_TX) 指定的网络 |  |
| 33 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (VM) 指定的网络 |  |
| 34 | parity | warning | net_conflict | 1 | 焊盘缺少原理图 (nFAULT) 指定的网络 |  |
